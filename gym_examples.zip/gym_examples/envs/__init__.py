from gym_examples.envs.grid_world import GridWorldEnv
from gym_examples.envs.star_wars import StarWarsEnv
from gym_examples.envs.cnn_env import CNNEnv